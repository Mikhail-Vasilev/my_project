﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace summa_vektorov
{
    class Program
    {
        static void Main(string[] args)
        {
            int gk = 0;
            while (gk == 0)
            {
                Console.WriteLine("Введите Х точки:");
                string a = Console.ReadLine();
                Console.WriteLine("Введите Y точки:");
                string b = Console.ReadLine();
                Console.WriteLine("Введите Х координат:");
                string c = Console.ReadLine();
                Console.WriteLine("Введите Y координат:");
                string d = Console.ReadLine();

                int x = Convert.ToInt32(a) + Convert.ToInt32(c);
                Console.WriteLine("{0}+{1}={2}", a, c, x);
                int y = Convert.ToInt32(b) + Convert.ToInt32(d);
                Console.WriteLine("{0}+{1}={2}", b, d, y);
                Console.WriteLine("Координаты точки...({0};{1})", x, y);
                int sum = x + y;
                Console.WriteLine("сумма равна:{0}+{1}={2}", x, y, sum);
                Console.WriteLine("Сумма координат точки:{0}", sum);
            }
            Console.ReadKey();
        }
    }
}
