﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dlinna_vektora_B1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите Х вектора:");
            string a = Console.ReadLine();
            Console.WriteLine("Введите Y вектора:");
            string b = Console.ReadLine();
            double sed =(Math.Pow(Convert.ToInt32(a),2));
            double set =(Math.Pow(Convert.ToInt32(b),2));
            double dlina =(Math.Sqrt( (Math.Pow(Convert.ToInt32(a),2)+(Math.Pow(Convert.ToInt32(b),2)))));
            Console.WriteLine("|...|=корень{0}^2+ {1}^2",a,b);
            Console.WriteLine("|...|=корень{0}+{1}={2}",sed,set,dlina);
            Console.WriteLine("Ответ:{0}",dlina);


            Console.ReadKey();
        }
    }
}
