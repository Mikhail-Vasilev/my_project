﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dlina_vektorov_B2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Программа считает как длюну вектора, так и длину суммы векторов!:)\n");
            Console.WriteLine("Введите первую сторону:");
            string a = Console.ReadLine();
            Console.WriteLine("Введите вторую сторону:");
            string b = Console.ReadLine();
          double one =(Math.Pow(Convert.ToInt32(a),2));
          double two = (Math.Pow(Convert.ToInt32(b), 2));
          double thre = one + two;
          double four = (Math.Sqrt(thre)); 
          Console.WriteLine("длина вектора=корень{0}^2+{1}^2=корень{2}={3}",a,b,thre,four);
          Console.WriteLine("Ответ:{0}",four);


            Console.ReadKey();
        }
    }
}
