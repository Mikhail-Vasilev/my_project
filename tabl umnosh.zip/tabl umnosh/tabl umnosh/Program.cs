﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tabl_umnosh
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ded = new int[11];
            int t = 0;
            int f =0;
            for (t = 2; t < 10; t++)
            {
                ded[t] = t;
                for (f = 2; f < 10; f++)
                {
                    ded[f] = f;

                    int tab = ded[t] * ded[f];
                    Console.WriteLine("{0}*{1}={2}", ded[t], ded[f], tab);
                }
            }

                Console.ReadKey();
        }
    }
}
