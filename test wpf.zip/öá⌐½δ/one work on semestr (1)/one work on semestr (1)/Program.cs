﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one_work_on_semestr__1_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("КАКОЙ У ВАС ХАРАКТЕР?");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Каждый из нас имеет определенные черты характера, среди которых есть хорошие и не очень.");
            Console.WriteLine("Попробуйте взглянуть на себя объективно и правдиво отвеить(да;нет;не знаю)на следующие 10 вопросов.\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ВНИМАНИЕ!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("на вопросы отвечать цифрами:\n 1)да\n 2)нет\n З)не знаю");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("УДАЧИ!\n");
            Console.ForegroundColor = ConsoleColor.White;
            
            int bal = 0;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("1) Посылая письмо кому либо из знакомых,считаете ли вы обязательным написать на конверте обратный адрес?");
            string a = "";
            while (a != "1" && a != "2" && a != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                a = Console.ReadLine();
                if (a == "1")
                {
                    bal = bal + 2;
                }
                if (a == "2")
                {
                    bal = bal + 0;
                }
                if (a == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("2) Употребляете ли зубную пасту и одеколон только одного определенного сорта?");
            string b = "";
            while (b != "1" && b != "2" && b != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                b = Console.ReadLine();
                if (b == "1")
                {
                    bal = bal + 2;
                }
                if (b == "2")
                {
                    bal = bal + 0;
                }
                if (b == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("3) Во время визита к знакомым обращаете ли внимание на разные мелкие недостатки либо недоделки в чужом доме\nНАПРИМЕР: криво повешана картина, тусклая лампочка в прихожей?");
            string c = "";
            while (c != "1" && c != "2" && c != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                c = Console.ReadLine();
                if (c == "1")
                {
                    bal = bal + 2;
                }
                if (c == "2")
                {
                    bal = bal + 0;
                }
                if (c == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("4) Поддерживаете ли вы в лчной библиотеке такой идеальный порядок, что без труда можно найти любую книгу?");
            string d = "";
            while (d != "1" && d != "2" && d != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                d = Console.ReadLine();
                if (d == "1")
                {
                    bal = bal + 2;
                }
                if (d == "2")
                {
                    bal = bal + 0;
                }
                if (d == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("5) Храните ли вы у себя разные 'реликвии' типа первой школьной тетради или театральной программы десятилетний давности?");
            string e = "";
            while (e != "1" && e != "2" && e != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                e = Console.ReadLine();
                if (e == "1")
                {
                    bal = bal + 2;
                }
                if (e == "2")
                {
                    bal = bal + 0;
                }
                if (e == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("6) Готовите ли с вечера одежду, обувь, портфель, сумку на завтрешний день?");
            string f = "";
            while (f != "1" && f != "2" && f != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                f = Console.ReadLine();
                if (f == "1")
                {
                    bal = bal + 2;
                }
                if (f == "2")
                {
                    bal = bal + 0;
                }
                if (f == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("7) Выйдя из дому, начинаете вспоминать, все ли оставлено в порядке(выключено, закрыто и т.д.)?");
            string g = "";
            while (g != "1" && g != "2" && g != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                g = Console.ReadLine();
                if (g == "1")
                {
                    bal = bal + 2;
                }
                if (g == "2")
                {
                    bal = bal + 0;
                }
                if (g == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("8) Проверяете ли пуговицы у своей одежды, прежде чем надеть ее?");
            string h = "";
            while (h != "1" && h != "2" && h != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                h = Console.ReadLine();
                if (h == "1")
                {
                    bal = bal + 2;
                }
                if (h == "2")
                {
                    bal = bal + 0;
                }
                if (h == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("9) Услыхав по радио сигнал точного времени, смотрете ли на свои часы?");
            string i = "";
            while (i != "1" && i != "2" && i != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                i = Console.ReadLine();
                if (i == "1")
                {
                    bal = bal + 2;
                }
                if (i == "2")
                {
                    bal = bal + 0;
                }
                if (i == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("10) Делаете ли вы замечания своим друзьям и знакомым по поводу их вкусов, манеры одеваться и т.п.?");
            string j = "";
            while (j != "1" && j != "2" && j != "3")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                j = Console.ReadLine();
                if (j == "1")
                {
                    bal = bal + 2;
                }
                if (j == "2")
                {
                    bal = bal + 0;
                }
                if (j == "3")
                {
                    bal = bal + 1;
                }
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("\nВаш Балл:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(bal);
            if (bal <= 6)
            {
                Console.WriteLine("\nВы принадлежите к людям, которым все безразлично.");
                Console.WriteLine("При какой-либо неудаче вы рассчитываете, что всегда найдется тот, кто поможет вам выпутаться из трудного положения.");
                Console.WriteLine("Однако, чаще всего, такие надежды не оправдываются. Друзьям на Вас надеяться трудно — вы легко можете подвести. Задумайтесь над своим характером.");
            }
            if (bal >= 7)
                if (bal <= 10)
                {
                    Console.WriteLine("С первого взгляда кажется, что Вы сторонник(ца) порядка и гармонии. Но это скорее всего видимость.");
                    Console.WriteLine("В действительности вы достаточно легкомысленны и часто желаемое выдаете за действительное. Следует пожелать вам больше постоянства и силы воли.");

                }
            if (bal >= 11)
                if (bal <= 16)
                {
                    Console.WriteLine("Прямо скажем, вы обладаете хорошим, ровным характером. Цените порядок в доме и там, куда попадаете (а главное, содействуете этому порядку!).");
                    Console.WriteLine("Любите аккуратность и стараетесь всегда держать данное вами слово. При оценке ситуации всегда взвешивайте все «за» и «против».");
                }
            if (bal >= 17)
            {
                Console.WriteLine("Вы, пожалуй, чрезмерно впечатлительный человек. Любая мелочь способна вывести вас из себя. Часто сетуете, что все хуже, чем того желали бы.");
                Console.WriteLine("Тот или иной взгляд или мнение (будь то чистота в доме, опрятность в одежде, нетерпимость к чему-либо и т. д.) вы можете превратить в культ");
                Console.WriteLine("С таким характером трудно уживаться с людьми.");
                Console.WriteLine("Надо хорошо отдавать себе отчет, в каких вопросах необходимо проявлять железную непримиримость, а в каких — мягкость и снисходительность");
            }
        Console.ReadKey();
        }
    }
}
