﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one_work_on_semestr__2_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("УВЕРЕНЫ ЛИ ВЫ В СЕБЕ?");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Определить, насколько вы уверены в себе вам поможет этот тест.");
            Console.WriteLine("Отвечайте на вопросы \"да\"или\"нет\".\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("ВНИМАНИЕ!");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("На вопросы отвечать цыфрами:\n1)да\n2)нет");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("УДАЧИ!");
            Console.ForegroundColor = ConsoleColor.White;
            int bal = 0;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("1) Могут ли несколько последовавших одна за другой неудач заставить вас усомниться в своих способностях?");
            Console.ForegroundColor = ConsoleColor.White;
            string a = "";
            while (a != "1" && a != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                a = Console.ReadLine();
                if (a == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("2) Испытываете ли вы чувство страха оказавшись в плотной толпе?");
            Console.ForegroundColor = ConsoleColor.White;
            string b = "";
            while (b != "1" && b != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                b = Console.ReadLine();
                if (b == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("3) Следуете ли вы моде?");
            Console.ForegroundColor = ConsoleColor.White;
            string c = "";
            while (c != "1" && c != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                c = Console.ReadLine();
                if (c == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("4) Часто ли смотритесь в зеркало?");
            Console.ForegroundColor = ConsoleColor.White;
            string d = "";
            while (d != "1" && d != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                d = Console.ReadLine();
                if (d == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("5) Сутулитесь ли вы?");
            Console.ForegroundColor = ConsoleColor.White;
            string e = "";
            while (e != "1" && e != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                e = Console.ReadLine();
                if (e == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("6) Считаете ли вы, что люди злословят по вашему адресу?");
            Console.ForegroundColor = ConsoleColor.White;
            string f = "";
            while (f != "1" && f != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                f = Console.ReadLine();
                if (f == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("7) Волнуетесь ли вы, когда вам приходится бывать в учреждениях, улаживая какие-либо неприятные вопросы? ");
            Console.ForegroundColor = ConsoleColor.White;
            string g = "";
            while (g != "1" && g != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                g = Console.ReadLine();
                if (g == "2")

                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("8) Возникает ли у Вас временами такое ощущение, будто за вами кто-то следит? ");
            Console.ForegroundColor = ConsoleColor.White;
            string h = "";
            while (h != "1" && h != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                h = Console.ReadLine();
                if (h == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("9. Легко ли вы решаетесь провести свой отпуск в новом для вас месте?");
            Console.ForegroundColor = ConsoleColor.White;
            string i = "";
            while (i != "1" && i != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                i = Console.ReadLine();
                if (i == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("10) Чувствуете ли вы себя свободно, оказавшись в незнакомой компании?");
            Console.ForegroundColor = ConsoleColor.White;
            string j = "";
            while (j != "1" && j != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                j = Console.ReadLine();
                if (j == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("11) Снятся ли вам кошмарные сны?");
            Console.ForegroundColor = ConsoleColor.White;
            string k = "";
            while (k != "1" && k != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                k = Console.ReadLine();
                if (k == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("12) Предпочитаете ли вы самостоятельно решать свои проблемы, не обсуждая их с близкими вам людьми?");
            Console.ForegroundColor = ConsoleColor.White;
            string l = "";
            while (l != "1" && l != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                l = Console.ReadLine();
                if (l == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("13) Откладываете ли вы деньги на «черный день»?");
            Console.ForegroundColor = ConsoleColor.White;
            string m = "";
            while (m != "1" && m != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                m = Console.ReadLine();
                if (m == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("14) Уверены ли вы в том, что ваши друзья любят вас?");
            Console.ForegroundColor = ConsoleColor.White;
            string o = "";
            while (o != "1" && o != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                o = Console.ReadLine();
                if (o == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("15) Находите ли вы, что каждый день можно узнавать нечто новое для себя?");
            Console.ForegroundColor = ConsoleColor.White;
            string p = "";
            while (p != "1" && p != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                p = Console.ReadLine();
                if (p == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("16) Установив, что купленная вещь вам не подходит, вернетесь ли вы в магазин, чтобы сменить ее?");
            Console.ForegroundColor = ConsoleColor.White;
            string q = "";
            while (q != "1" && q != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                q = Console.ReadLine();
                if (q == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("17) Терзаетесь ли вы сомнениями насчет того, удастся ли вам осуществить намеченные цели?");
            Console.ForegroundColor = ConsoleColor.White;
            string r = "";
            while (r != "1" && r != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                r = Console.ReadLine();
                if (r == "2")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("18) Часто ли окружающие обращяются к вам за советом?");
            Console.ForegroundColor = ConsoleColor.White;
            string s = "";
            while (s != "1" && s != "2")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Ваш ответ:");
                Console.ForegroundColor = ConsoleColor.White;
                s = Console.ReadLine();
                if (s == "1")
                {
                    bal = bal + 2;
                }
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\nВаш балл:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("{0}\n", bal);
                if (bal <= 4)
                {
                    Console.Write("Такая сумма баллов в это м тесте встречается, к счастью, весьма редко.");
                    Console.WriteLine("И если вы искренне отвечали на все вопросы, то вам следует побеседовать с психотерапевтом, который поможет вам обрести уверенность в себе.");
                }
            if (bal >= 6)
                if (bal <= 14)
                {
                    Console.Write("Можно утверждать, вы не уверены в себе и вам не удается скрыть это от окружающих.");
                    Console.WriteLine("Вы необщительны и стараетесь не попадать в такое положение, которое вынудило бы вас самостоятельно принять важно решение.");
                }
            if (bal >= 16)
                if (bal <= 24)
                {
                    Console.WriteLine("Вы уверены в себе, хотя, бывает, проявляете не решительность. Этот тест предоставляет вам возможность дать себе более точною самооценку.");
                }
            if (bal >= 26)
                if (bal <= 36)
                {
                    Console.Write("Вам не когда не случалось сомневаться в себе или в своих способностях.");
                    Console.WriteLine("Окружающие обращаются вам за советами.Кое - кто считает, что вы тщеславны и ведете себя надменно.");

                }
            Console.ReadKey();
        }
    }
}
